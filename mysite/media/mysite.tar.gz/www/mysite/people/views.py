from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.http import Http404

#from django.template import Context, loader
from mysite.people.models import *
#from django.http import HttpResponse
from datetime import datetime, timedelta

#def page(request, user_id):
#    u = get_object_or_404(User, pk=user_id)
people_domain_name = 'topsecret.communizm.ru'
PEOPLE_REGISTER_URL = 'http://topsecret.communizm.ru/people/register/'

def register(request, hash_value):
	if Invite.objects.filter(hash_value = hash_value):
		valid_hash = True
	else:
		valid_hash = False
		
	if request.method == 'POST': # If the form has been submitted...
		form = RegisterUserForm(request.POST) # A form bound to the POST data
		if form.is_valid(): # All validation rules pass
			user = form.save()
			user.set_password(form.cleaned_data['password'])
			user.friends.add((Invite.objects.get(hash_value = hash_value)).user_invited)
			user.save()
			user_login = authenticate(username = user.username, password=form.cleaned_data['password'])
			login (request, user_login)

			#user = MyUser.objects.create_user(form.username, '', form.password)
			# Process the data in form.cleaned_data
			# ...
			return HttpResponseRedirect('/people/profile') # Redirect after POST
	else:
		form = RegisterUserForm()

	return render_to_response('people/register.html', {"formset": form, "valid_hash": valid_hash}) 

from django.contrib.auth import authenticate, login

def login_user(request):
    form = LoginUserForm()
    if request.method == 'POST': # If the form has been submitted...
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect('/people/') # Redirect after POST
                # Redirect to a success page.
            else:
                return 0
            # Return a 'disabled account' error message
        else:
            # Return an 'invalid login' error message.  
            form = LoginUserForm(request.POST)
        
    return render_to_response('people/login.html', {"formset": form}) 

def myuser_detail(request, object_id):
	object =  get_object_or_404(MyUser, id=object_id)
	friendofs = MyUser.objects.filter(friends__username = object.username)
	user = MyUser.objects.get(id=request.user.id)
	
	if friendofs.filter(id = user.id).count() == 0:
		friendable = True
	else:
		friendable = False
	
	if (object == user):
		friendable = False
		
	friends_online = object.friends.filter(last_active__gte = datetime.now() - timedelta(minutes=3))
	fence_messages = FenceMessage.objects.filter(recipient__id = object_id)
	return render_to_response('people/myuser_detail.html',
#		[friendofs, user, friendable, fence_messages],
#		{"object": object})
		{"object": object, "friendofs": friendofs, "user": user, 
		"friendable": friendable, "fence_messages": fence_messages, "friends_online": friends_online})

def myuser_profile(request):
	return myuser_detail(request, request.user.id)
	# object =  get_object_or_404(MyUser, id=request.user.id)
	# friendofs = MyUser.objects.filter(friends__username = object.username)
	# return render_to_response('people/myuser_detail.html', {"object": object, "friendofs": friendofs, "user": request.user})

def myuser_make_friends(request, user_id):
	user = MyUser.objects.get(id=request.user.id)
	user.friends.add(MyUser.objects.get(id=user_id))
	return myuser_profile(request)
	
def myuser_profile_change(request):
	user = MyUser.objects.get(id=request.user.id)
	if request.method == 'POST': # If the form has been submitted...
		form = ChangeProfileForm(request.POST, request.FILES, instance = user)
		if form.is_valid():
			form.save()
			user.save()
			return HttpResponseRedirect(reverse('people.views.myuser_profile')) # Redirect after POST
	else:
		form = ChangeProfileForm(instance = user)
	return render_to_response('people/myuser_profile_change.html', {"form": form, "user": request.user})

def col_blog(request):
	posts = BlogPost.objects.all()
	return render_to_response('people/col_blog.html', {"posts": posts, "user": request.user})
	
def send_invite(request):
	from django.core.mail import send_mail
	if request.method == 'POST': # If the form has been submitted...
		form = InviteForm(request.POST)
		if form.is_valid():
			invite = Invite()
			host = MyUser.objects.get(id=request.user.id)
			invite.assign_user(host)
			url = '\n '+ PEOPLE_REGISTER_URL + invite.hash_value + '/'
			invite.save()
			message = form.cleaned_data['message'] + url
			
			send_mail(form.cleaned_data['subject'], 
						message, 
						host.username + '@' +  people_domain_name, 
						[form.cleaned_data['recipient']], 
						fail_silently=False)
						
			#user = MyUser.objects.get(id=request.user.id)
			host.number_of_invites -= 1
			host.save()
			return HttpResponseRedirect('/people/') # Redirect after POST
	
	if request.user.is_authenticated():
		#form = InviteForm( {'subject': 'From: ' + request.user.first_name})
		form = InviteForm()
		user = MyUser.objects.get(id=request.user.id)
		number_of_invites = user.number_of_invites 
	else:
		form = InviteForm()
		number_of_invites = 0 
	
	return render_to_response('people/send_invite.html', {"user": request.user, "form": form, 'number_of_invites': number_of_invites})

def fence_write(request, user_id):
	if request.method == 'POST': # If the form has been submitted...
		fence_message = FenceMessage(author_id = request.user.id, recipient_id = user_id)
		form = SendFenceForm(request.POST, instance = fence_message)	
		if form.is_valid():
			form.save()
			return HttpResponseRedirect(reverse('people.views.myuser_profile'))
	else:
		form = SendFenceForm()
	
	return render_to_response('people/fence.html', { "form": form, "user": request.user, "recipient_id": user_id})	
	
def mail(request, template):
	user = MyUser.objects.get(id=request.user.id)
	inbox = Message.objects.filter(recipient = user.username)
	sent = Message.objects.filter(author = user)
	if request.method == 'POST': # If the form has been submitted...
		message = Message(author = user)
		form = SendMailForm(request.POST, instance = message)	
		if form.is_valid():
			form.save()
			return HttpResponseRedirect(reverse('people.views.mail'))
	else:
		form = SendMailForm()
	
	form.author = user.username
	# return render_to_response('people/mail.html', {
													# "user": request.user, "form": form, "inbox": inbox, 
													# "sent": sent, "author": user})
	return render_to_response( template , {
													"user": request.user, "form": form, "inbox": inbox, 
													"sent": sent, "author": user})
def mail_inbox(request):
	return mail(request, 'people/mail_inbox.html')

def mail_sent(request):
	return mail(request, 'people/mail_sent.html')

def mail_compose(request):
	return mail(request, 'people/mail_compose.html')

	
def main(request):
	if (request.user):
		if (MyUser.objects.all().filter(id=request.user.id)):
			return myuser_profile(request)

	
	max = MainMessage.objects.all().count()
	if (max >= 1):
		import random
		welcome_message = get_object_or_404(MainMessage, id = random.randint(1, max))
	else:
		welcome_message = get_object_or_404(MainMessage, id = 0)
	return render_to_response('people/welcome.html', {"welcome_message": welcome_message})

# def func(request):

	# if request.method == 'POST': # If the form has been submitted...
		# form = SendMailForm(request.POST, instance = message)	
		# if form.is_valid():
			# form.save()
			# return HttpResponseRedirect(reverse('people.views.mail'))
	# else:
		# form = SendMailForm()
	
	# return render_to_response('people/mail.html',)													