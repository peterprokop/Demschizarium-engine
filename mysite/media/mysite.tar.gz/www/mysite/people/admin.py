#from mysite.people.models import MyUser, Invite, Message, BlogPost
from mysite.people.models import *
from django.contrib import admin

#admin.site.register(Choice)
class MyUserAdmin(admin.ModelAdmin):
  fieldsets = [
        (None,               {'fields': ['username']}),
        (None,               {'fields': ['first_name', 'last_name']}),
        (None,               {'fields': ['email']}),
#        ('Date information', {'fields': ['birth_date']}),
#        (None,               {'fields': ['about']}),
#        (None,               {'fields': ['user_picture']}),
#        (None,               {'fields': ['homepage']}),
        (None,               {'fields': ['friends']}),
		(None,               {'fields': ['number_of_invites']}),
		(None,               {'fields': ['userpic']}),
    ]

  list_display = ('username', 'first_name', 'last_name', 'email',)
  list_filter = ['last_name', 'first_name']
  search_fields = ['last_name', 'first_name']
#  date_hierarchy = 'birth_date'

admin.site.register(MyUser, MyUserAdmin)
admin.site.register(Invite)
admin.site.register(Message)
admin.site.register(MainMessage)
admin.site.register(BlogPost) 
admin.site.register(FenceMessage)