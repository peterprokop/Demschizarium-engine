from django.conf.urls.defaults import *
from mysite.people.models import MyUser
from mysite.people.views import *

info_dict = {
    'queryset': MyUser.objects.all(),
}

urlpatterns = patterns('',
    (r'^$', 'people.views.main'),
    (r'^(?P<object_id>\d+)/$', 'mysite.people.views.myuser_detail',),
    (r'^(?P<user_id>\d+)/fence-write$', 'mysite.people.views.fence_write',),
    (r'^(?P<user_id>\d+)/make-friends$', 'mysite.people.views.myuser_make_friends',),
    (r'^register$', 'people.views.register', {'hash_value': ''}),
    (r'^register/(?P<hash_value>\w+)/$', 'people.views.register'),
    (r'^profile$', 'people.views.myuser_profile'),
    (r'^profile/change$', 'people.views.myuser_profile_change'),
    (r'^send_invite$', 'people.views.send_invite'),
    (r'^mail$', 'people.views.mail', {'template': 'people/mail_sent.html'}),
    (r'^mail/inbox$', 'people.views.mail_inbox'),
    (r'^mail/sent$', 'people.views.mail_sent'),
    (r'^mail/compose$', 'people.views.mail_compose'),
    (r'^col_blog$', 'people.views.col_blog'),
    (r'^login$', 'django.contrib.auth.views.login', {'template_name': 'people/login.html'}),
    (r'^logout$', 'django.contrib.auth.views.logout', {'next_page': '/people/'}),
#    url(r'^(?P<object_id>\d+)/results/$', 'django.views.generic.list_detail.object_detail', dict(info_dict, template_name='users/results.html'), 'poll_results'),
#    (r'^(?P<poll_id>\d+)/vote/$', 'mysite.polls.views.vote'),
)
