#! /usr/bin/env python
# -*- coding: utf-8 -*-
from django import forms
from django.db import models
from django.forms import ModelForm
from django.core.urlresolvers import reverse
from django.contrib.auth.models import User
from stdimage import StdImageField
import datetime

message_initial = "Привет! Приглашаю тебя вступить в ХХХ, антисоциальную сеть нового поколения (с блэкджэком и шлюхами)."
#message_initial = "Hi! I am inviting you to XXX, a new era antisocial network (with blackjack and hookers)."
people_nosuchuser_error = u"Нет такого пользователя: "
people_useralreadyexists_error = u"Пользователь с таким именем уже существует!"
#GENDER_CHOICES = (
#  (u'M', u'Male'),
# (u'F', u'Female'),
#)


	    
class Country (models.Model):
	name = models.CharField(max_length=128)

class City (models.Model):
	name = models.CharField(max_length=128)
	country = models.ForeignKey("Country")
	
class MyUser (User):
	last_active = models.DateTimeField(null=True, blank=True)
	friends = models.ManyToManyField("self", symmetrical=False, blank=True, null=True)
	number_of_invites = models.IntegerField(default=3)
	userpic = StdImageField(upload_to='userpics', blank=True, size=(192, 192), thumbnail_size=(64, 64))
	
	country = models.ForeignKey("Country", null=True)
	city = models.ForeignKey("city", null=True)
	#userpic = models.ImageField(upload_to='userpics')
	#miniuserpic = models.ImageField(upload_to='miniuserpics')
	
	def __unicode__(self):
		return self.username
	
	# check if really needed
	def clean_username(self):
		data = self.cleaned_data['username']
		if MyUser.objects.all.get(username=data):
			raise forms.ValidationError(people_useralreadyexists_error)
		return data
		
	# def resize_userpic(self):
		# import Image
		# import os, sys
		
		# userpic_file = str(self.userpic.file)
		# size = 192, 192
		# miniuserpic_size = 64, 64
		# try:
			# im = Image.open(userpic_file)
			# im.thumbnail(size, Image.ANTIALIAS)
			# im.save(userpic_file)
			# im.thumbnail(miniuserpic_size, Image.ANTIALIAS)
			# im.save('mini' + userpic_file)
		# except IOError:
			# print "cannot create thumbnail for", userpic_file
			
class Message(models.Model):
	author = models.ForeignKey("MyUser", related_name='author')
#	recipient = models.ForeignKey("MyUser", related_name='recipient')
	recipient = models.CharField(max_length=256)
	subject = models.CharField(max_length=256)
	body = models.TextField()
	sent_time = models.DateTimeField(auto_now_add = True)
	
	def __unicode__(self):
		return "From: " + self.author.username + " To:" + self.recipient + " subj:" + self.subject + " body:" + self.body
	
class FenceMessage(models.Model):
	author = models.ForeignKey("MyUser", related_name='fence_author')
	recipient = models.ForeignKey("MyUser", related_name='recipient')
	body = models.TextField()
	sent_time = models.DateTimeField(auto_now_add = True)

class MainMessage(models.Model):
	text = models.TextField()
	picture = models.ImageField(upload_to='main_pics')
	
class Invite (models.Model):
	user_invited = models.ForeignKey("MyUser")
	hash_value = models.CharField(max_length=32)
	
	def assign_user(self, myuser):
		import hashlib, datetime, random
		self.user_invited = myuser
		hash = hashlib.md5()
		hash.update(
			str(datetime.datetime.now()) +
			str(myuser.id) + 
			str(random.random())
			)
		self.hash_value = hash.hexdigest()

class BlogPost (models.Model):
	body = models.TextField()
	pub_date = models.DateTimeField(auto_now_add = True)
	author = models.ForeignKey("MyUser")
	
	def __unicode__(self):
		return self.body
###
#Forms, here they are!
###
class RegisterUserForm (ModelForm):
    password = forms.CharField(widget = forms.PasswordInput, label='Пароль')
    username = forms.CharField(initial = "bazil_poupkine", label='Имя пользователя')
    class Meta:
        model = MyUser
        fields = ('username', 'email', 'password')

#        exclude = (
#          'first_name', 'last_name', 
#          'is_staff', 'is_active', 'is_superuser',
#          'last_login', 'date_joined', 'groups', 'user_permissions'
#         )

class LoginUserForm (ModelForm):
    password = forms.CharField(widget = forms.PasswordInput, label='Пароль')
    username = forms.CharField(initial = "bazil_poupkine", label='Имя пользователя')
    class Meta:
        model = MyUser
        fields = ('username', 'password')

class ChangeProfileForm (ModelForm):
	#password = forms.CharField(widget = forms.PasswordInput)
	email = forms.EmailField(label='Почта')
	userpic = forms.ImageField(label='Картинка пользователя')
	class Meta:
		model = MyUser
		fields = ('first_name', 'last_name', 'email', 'country', 'city', 'userpic') #, 'password'
		

class InviteForm (forms.Form):
    subject = forms.CharField(max_length=256, label='Тема письма')
    message = forms.CharField(initial=message_initial, label='Сообщение', widget=forms.Textarea)
    recipient = forms.EmailField(label='E-mail жертвы')

class SendMailForm (ModelForm):
	subject = forms.CharField(max_length=256, label='Тема письма')
	body = forms.CharField(label='Сообщение', widget=forms.Textarea)
	recipient = forms.CharField(label='Адресат')
	
	def clean(self):
		if (not MyUser.objects.all().filter(username = self.cleaned_data['recipient'])):
			raise forms.ValidationError(people_nosuchuser_error + self.cleaned_data['recipient'])
		return self.cleaned_data

	class Meta:
		model = Message
		fields = ('recipient', 'subject', 'body')
		
class SendFenceForm (ModelForm):
	body = forms.CharField(label='Сообщение', widget=forms.Textarea)
	
	class Meta:
		model = FenceMessage
		fields = ('body')
###
#Phew, no more forms!
###

#class ActivityMiddleware(object):
#    def process_request(self, request):
#	if request.user.is_authenticated():
#    	    now = datetime.now()
#	    profile = MyUser.objects.get(id = request.user.id)
#	    if profile.last_active is None:
#	    #workaround for profiles not having last_active set
#	        try:
#	            profile.last_active = now
#	            profile.save()
#	        except:
#	            pass
#	if profile.last_active is not None:
#	    profile.last_active = now
#	    profile.save()
