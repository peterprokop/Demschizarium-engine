import datetime
from mysite.people.models import MyUser

class ActivityMiddleware(object):
    def process_request(self, request):
	if request.user.is_authenticated():
	    now = datetime.datetime.now()
	    if (MyUser.objects.filter(id = request.user.id)):
		profile = MyUser.objects.get(id = request.user.id)
    		if profile.last_active is None:
		    #workaround for profiles not having last_active set
		    try:
			profile.last_active = now
			profile.save()
		    except:
			pass

		if profile.last_active is not None:
		    profile.last_active = now
		    profile.save()
